package com.example.trash;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Date;

import java.util.ArrayList;

public class ObjectListAdapter extends ArrayAdapter<trashObject> {
        private Context nContext;


        private int r;
        public ObjectListAdapter(Context c, int resource, ArrayList<trashObject> p){
            super(c, resource, p);
            nContext = c;
            r = resource;
        }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            String name = getItem(position).getName();
            String type = getItem(position).getType();
            Date d = getItem(position).getTime();

            trashObject o = new trashObject(name, type, d);
        LayoutInflater inflater = LayoutInflater.from(nContext);
        convertView = inflater.inflate(r, parent, false);
        TextView tvName = (TextView) convertView.findViewById(R.id.textView1);
        TextView tvType = (TextView) convertView.findViewById(R.id.textView2);
        TextView tvDate = (TextView) convertView.findViewById(R.id.textView3);
        tvName.setText(name);
        tvType.setText(type);
        tvDate.setText(d.toString());
        return convertView;
    }
}
