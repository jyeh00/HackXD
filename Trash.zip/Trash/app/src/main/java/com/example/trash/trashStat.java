package com.example.trash;

public class trashStat {
    private int quantity;
    private String name;
    public trashStat(int q, String n){
        quantity = q;
        name = n;
    }

    public String getName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }
}
