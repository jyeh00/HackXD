package com.example.trash;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;

import android.view.View;
import android.widget.Button;

import java.util.ArrayList;
import java.util.Date;

public class SecondActivity extends AppCompatActivity {
    private Button signout;
    private Button history;
    private Button objects;
    private Button category;
    private PieChart current;
    private ArrayList<trashObject> trashObjects;
    private ArrayList<trashStat> stats = new ArrayList<trashStat>();
    private ArrayList<trashStat> cstats = new ArrayList<trashStat>();
    private String[] categories = {"Compostable Material", "Recyclable Material", "Waste Material"};
    private int[] categoriesq = new int[3];
    private PieChart current2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        trashObjects = new ArrayList<trashObject>();
        current = (PieChart)(findViewById(R.id.objectchart));
        current2 = (PieChart)(findViewById(R.id.objectchart2));
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        signout = (Button)(findViewById(R.id.signout));
        history = (Button)(findViewById(R.id.history));
        category = (Button)(findViewById(R.id.stats));
        objects = (Button)(findViewById(R.id.objects));
        signout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signout();
            }
        });
        category.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                current2.setVisibility(View.VISIBLE);
                current.setVisibility(View.INVISIBLE);
            }
        });
        objects.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                current.setVisibility(View.VISIBLE);
                current2.setVisibility(View.INVISIBLE);
            }
        });
        history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SecondActivity.this, ThirdActivity.class);
                Intent i = new Intent(SecondActivity.this, ThirdActivity.class);
                //i.putParcelableArrayListExtra("stringkey", trashObjects);
                //i.putParcelableArrayListExtra("trashObjects", trashObjects);
                startActivity(intent);
            }
        });
        addNew();
        setupPieChart();
        setupCategoriesPieChart();
    }
    private void addNew(){
        trashObjects.add(new trashObject("Banana","Compostable Material", new Date()));
        trashObjects.add(new trashObject("Pineapple","Compostable Material", new Date()));
        trashObjects.add(new trashObject("Pizza","Waste Material", new Date()));
        trashObjects.add(new trashObject("Water Bottle","Recyclable Material", new Date()));
        stats.add(new trashStat(1, "Banana"));
        stats.add(new trashStat(1, "Pineapple"));
        stats.add(new trashStat(1, "Pizza"));
        stats.add(new trashStat(1, "Water Bottle"));
        categoriesq[0] = 2;
        categoriesq[1] = 1;
        categoriesq[2] = 1;
    }

    private void signout(){
        AlertDialog.Builder a = new AlertDialog.Builder(SecondActivity.this);
        a.setMessage("Are you sure you want to sign out?").setCancelable(false).setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(SecondActivity.this, MainActivity.class);
                startActivity(intent);
            }
        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog alert = a.create();
        alert.show();

    }
    private void setupCategoriesPieChart(){
        ArrayList<PieEntry> pieEntries = new ArrayList<>();

        for(int i = 0; i <3; i++){
            pieEntries.add(new PieEntry(categoriesq[i], categories[i]));
        }
        PieDataSet dataSet = new PieDataSet(pieEntries, "objectsChart");
        dataSet.setColors(getResources().getColor(R.color.compost),getResources().getColor(R.color.recyclable),getResources().getColor(R.color.waste));
        PieData data = new PieData(dataSet);

        current2 = (PieChart) findViewById(R.id.objectchart2);

        current2.setData(data);
        current2.setVisibility(View.INVISIBLE);
    }
    private void setupPieChart(){
        ArrayList<PieEntry> pieEntries = new ArrayList<>();

        for(int i = 0; i <stats.size(); i++){
            pieEntries.add(new PieEntry((stats.get(i).getQuantity()), stats.get(i).getName()));
        }
        PieDataSet dataSet = new PieDataSet(pieEntries, "objectsChart");
        dataSet.setColors(ColorTemplate.COLORFUL_COLORS);
        PieData data = new PieData(dataSet);

        current = (PieChart) findViewById(R.id.objectchart);

        current.setData(data);
    }

    private boolean hasObject(ArrayList<trashObject> a, String name){
        for(int i = 0; i <a.size(); i++){
            if(a.get(i).getName().equalsIgnoreCase(name))
                return true;
        }
        return false;
    }


}
