package com.example.trash;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.widget.Button;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Date;

public class ThirdActivity extends AppCompatActivity {
    private Button goback;

    private ArrayList<trashObject> trashObjects;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        trashObjects = new ArrayList<trashObject>();
        trashObjects.add(new trashObject("Banana","Compostable Material", new Date()));
        trashObjects.add(new trashObject("Pineapple","Compostable Material", new Date()));
        trashObjects.add(new trashObject("Pizza","Waste Material", new Date()));
        trashObjects.add(new trashObject("Water Bottle","Recyclable Material", new Date()));
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
        goback = (Button)findViewById(R.id.goback);

        goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ThirdActivity.this, SecondActivity.class);
                startActivity(intent);
            }
        });
        ListView list= (ListView)findViewById(R.id.list);
        Intent i = getIntent();
        ObjectListAdapter adapter = new ObjectListAdapter(this, R.layout.custom_view_layout, trashObjects);
        list.setAdapter(adapter);
    }

}
