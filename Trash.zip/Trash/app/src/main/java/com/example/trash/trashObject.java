package com.example.trash;

import android.graphics.Color;
import android.os.Parcelable;

import java.util.Date;

public class trashObject{

    private String type;
    private String name;
    private Date time;



    trashObject(String a, String b, Date c){
        name = a;
        type = b;
        time = c;
    }

    public String getName() {
        return name;
    }

    public Date getTime() {
        return time;
    }

    public String getType() {
        return type;
    }

}
